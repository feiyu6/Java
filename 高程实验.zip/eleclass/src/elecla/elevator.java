package elecla;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class elevator {
	elevators elecs = new elevators();
	public class elevators extends Frame implements ActionListener{               //����ģ��
		theElevators lEle = new theElevators("left");      //������������
		theElevators rEle = new theElevators("right");
			
		floorButton[] flB = new floorButton[9];         //9��¥�㰴ť
			
		scene lScene = new scene("left: ");       //����������������������������һ�����û�����
		scene rScene = new scene("right:");
		scene allScene = new scene("all:  ");
			
		int[] count = new int[11];           //������ʾ
		Button []up = new Button[9];              //¥����Ŀ��ѡ��ť
		Button []down = new Button[9];
		
		innerButton leftB = new innerButton("left");       //�����ڰ�ť
		innerButton rightB = new innerButton("right");
		
		Button quit = new Button("Quit");         //�˳���ť
		Button rst = new Button("Reset");       //���ð�ť
		
		inButton []Rx = new inButton[10];
		inButton []Lx = new inButton[10];

		Panel telPanel = new Panel();       //���ݿ��
		Panel floorPanel = new Panel();    //¥����
		Panel allPanel = new Panel();			//�ܿ��
		Panel myScene = new Panel();			//���������
		Panel up_down = new Panel();			//¥�㰴ť���
		Panel telB = new Panel();			//�ܰ�ť���
		Panel inA = new Panel();			//�ڲ���ť���
		Panel inB = new Panel();			//���ҵ��ݰ�ť���
		Panel inR = new Panel();	
		Panel inL = new Panel();
		Panel con = new Panel();
		Container floors = new Container();        //¥������
		
		public elevators()           //��ʼ������
		{
			super("my elevator");         //����
			inR.add(inB);
			inR.add(rightB);
			inL.add(leftB);
			inL.add(inA);
			
			con.add(quit);
			con.add(rst);
			
			myScene.setLayout(new BorderLayout());
			myScene.add("Center",allScene);
			myScene.add("North",lScene);	
			myScene.add("South",rScene);
			
			telB.setLayout(new BorderLayout());
			telB.add("East",inR);
			telB.add("North",myScene);
			telB.add("Center",up_down);
			telB.add("West",inL);
			
			floors.setLayout(new BorderLayout());
			floors.add("Center",floorPanel);
			
			floorPanel.setLayout(new GridLayout(9,6));	
			inB.setLayout(new GridLayout(3,3));
			inA.setLayout(new GridLayout(3,3));
			up_down.setLayout(new GridLayout(9,2));
			telPanel.setLayout(new BorderLayout());
			
			telPanel.add("Center",floors);
			telPanel.add("West",lEle);	
			telPanel.add("East",rEle);	
			telPanel.add("South",con);
			
			for(int i=8;i>-1;i--)
			{
				String a=i+"";
				if(i!=0)
				{
					Rx[i]=new inButton(a);
					inB.add(Rx[i]);
					Rx[i].addActionListener(this);
				}
				else
				{
					a=i-1+"";
					Rx[i]=new inButton(a);
					inB.add(Rx[i]);
					Rx[i].addActionListener(this);
				}
			}
			for(int i=8;i>-1;i--)
			{
				String a=i+"";
				if(i!=0)
				{
					Lx[i]=new inButton(a);
					inA.add(Lx[i]);
					Lx[i].addActionListener(this);
				}
				else
				{
					a=i-1+"";
					Lx[i]=new inButton(a);
					inA.add(Lx[i]);
					Lx[i].addActionListener(this);
				}
			}
			for(int i=8;i>-1;i--)
			{
				if(i!=0)
				{
					up[i]=new Button(i+"  up");
					up_down.add(up[i]);
					up[i].addActionListener(this);
					down[i]=new inButton(i+"  down");
					up_down.add(down[i]);
					down[i].addActionListener(this);
				}
				else
				{
					up[i]=new Button(i-1+" up");
					up_down.add(up[i]);
					up[i].addActionListener(this);
					down[i]=new inButton(i-1+" down");
					up_down.add(down[i]);
					down[i].addActionListener(this);
				}
			}
			for(int i=8;i>-1;i--)
			{
				String a=i+"";
				if(i!=0)
				{
					flB[i]=new floorButton(a);
					floorPanel.add(flB[i]);
					for(int j=0;j<5;j++)
						floorPanel.add(new floorRect(j));
					flB[i].addActionListener(this);
				}
				else
				{
					a=i-1+"";
					flB[i]=new floorButton(a);
					floorPanel.add(flB[i]);
					for(int j=0;j<5;j++)
						floorPanel.add(new floorRect(j));
					flB[i].addActionListener(this);
				}
			}
			pack();
			this.setResizable(false);
			setSize(800,500);
			
			allPanel.setLayout(new BorderLayout());
			allPanel.add("Center",telPanel);
			allPanel.add("East",telB);
			
			add(allPanel);
			
			quit.addActionListener(this);
			rst.addActionListener(this);
			rightB.addActionListener(this);
			leftB.addActionListener(this);
			allPanel.setVisible(true);
			setVisible(true);

			lEle.start();
			rEle.start();                       //�������ݽ���
		}
		public void actionPerformed(ActionEvent e) {            //��ť�¼�������
			if(e.getSource()==quit)             //�˳�
				System.exit(0);
			if(e.getSource()==rst)                 //��λ
			{
				inA.setVisible(false);
				inB.setVisible(false);
				for(int i=0;i<9;i++)
				{
					up[i].setVisible(false);
					down[i].setVisible(false);
				}
				rScene.free();
				lScene.free();
				allScene.free();
				rEle.reset();
				lEle.reset();
				for(int i=0;i<11;i++)
					count[i] = 0;
			}
			for(int i=0;i<9;i++)
			{
				if(e.getSource()==flB[i])
				{
					count[i] = count[i]+1;
					if(count[i]%2==1)
					{
						up[i].setVisible(true);
						down[i].setVisible(true);
					}
					else {
						up[i].setVisible(false);
						down[i].setVisible(false);
					}
					if(count[i]==20)
						count[i] = 0;
				}
			}
			if(e.getSource()==leftB)
			{
				count[9] = count[9]+1;
				if(count[9]%2==1)
					inA.setVisible(true);
				else
					inA.setVisible(false);
			}
			if(e.getSource()==rightB)
			{
				count[10] = count[10]+1;
				if(count[10]%2==1)
					inB.setVisible(true);
				else
					inB.setVisible(false);
			}
			for(int i=0;i<9;i++)
			{
				if(e.getSource()==Rx[i])
				{
					rScene.addnum(i,rEle.eleStyle,rEle.nowFloor);
				}
			}
			for(int i=0;i<9;i++)
			{
				if(e.getSource()==Lx[i])
				{
					lScene.addnum(i,lEle.eleStyle,lEle.nowFloor);
				}
			}
			for(int i=0;i<9;i++)
			{
				if(e.getSource()==up[i])
				{
					int whatScene=allScene.newupnum(i, lEle.nowFloor, lEle.eleStyle, rEle.nowFloor, rEle.eleStyle);
					if(whatScene==1)
					{
						lScene.addnum(i,lEle.eleStyle,lEle.nowFloor);
						if((lScene.sNode[0]!=0)&(lEle.nextFloor==0)&(lScene.sNode[0]!=lEle.nowFloor))
						{
							lEle.nextFloor=lScene.sNode[0];
						}
					}
					else if(whatScene==2)
					{
						rScene.addnum(i,rEle.eleStyle,rEle.nowFloor);
						if((rScene.sNode[0]!=0)&(rEle.nextFloor==0)&(rScene.sNode[0]!=rEle.nowFloor))
						{
							rEle.nextFloor=rScene.sNode[0];
						}
					}
				}
			}
			for(int i=0;i<9;i++)
			{
				if(e.getSource()==down[i])
				{
					int whatScene=allScene.newdownnum(i, lEle.nowFloor, lEle.eleStyle, rEle.nowFloor, rEle.eleStyle);
					if(whatScene==1)
					{
						lScene.addnum(i,lEle.eleStyle,lEle.nowFloor);
					}
					else if(whatScene==2)
					{
						rScene.addnum(i,rEle.eleStyle,rEle.nowFloor);
					}
				}
			}
		}
	}
	public class theElevators extends Canvas implements Runnable{             //������
		Thread thetel = new Thread(this);
		int nowFloor;                    //��ǰ¥��
		int nextFloor;                   //Ŀ��¥��
		int eleStyle;                    //����״̬
		String EleName;              //��������
		int Ey;                      //��������
		Color  thecolor;           //������ɫ
		boolean rs;
		public theElevators(String a) {            //���ݵĹ��캯��
			this.setSize(42, 1000);
			this.EleName = a;
			this.nowFloor = 1;
		}
		public void paint(Graphics g) {            //��ͼ
			g.setColor(thecolor);
			if(this.Ey>400)
				this.Ey = 379;
			if(this.EleName=="right")
				g.drawRect(0, this.Ey, 40, 45);
			else if(this.EleName=="left")
				g.drawRect(0, this.Ey, 40, 45);
		}
		public void move() {                               //���ݵ������ƶ�
			this.thecolor = new Color(0,0,0);
			if(this.EleName=="right")                 //ͬ·����������
			{
				if(elecs.rScene.sNode[0]!=0)
				{
					if((this.nowFloor<elecs.rScene.sNode[0])&(this.eleStyle==1)&(this.nextFloor>elecs.rScene.sNode[0]))
				{
					elecs.rScene.addnum(this.nextFloor, this.eleStyle, this.nowFloor);
					this.nextFloor = elecs.rScene.sNode[0];
					elecs.rScene.pushnum();
				}
				else if((this.nowFloor>elecs.rScene.sNode[0])&(this.eleStyle==-1)&(this.nextFloor<elecs.rScene.sNode[0]))
				{
					elecs.rScene.addnum(this.nextFloor, this.eleStyle, this.nowFloor);
					this.nextFloor = elecs.rScene.sNode[0];
					elecs.rScene.pushnum();
				}
				}
			}
			else if(this.EleName=="left")
			{
				if(elecs.rScene.sNode[0]!=0)
				{
				if((this.nowFloor<elecs.lScene.sNode[0])&(this.eleStyle==1)&(this.nextFloor>elecs.lScene.sNode[0]))
				{
					elecs.lScene.addnum(this.nextFloor, this.eleStyle, this.nowFloor);
					this.nextFloor = elecs.lScene.sNode[0];
					elecs.lScene.pushnum();
				}
				else if((this.nowFloor>elecs.lScene.sNode[0])&(this.eleStyle==-1)&(this.nextFloor<elecs.lScene.sNode[0]))
				{
					elecs.lScene.addnum(this.nextFloor, this.eleStyle, this.nowFloor);
					this.nextFloor = elecs.lScene.sNode[0];
					elecs.lScene.pushnum();
				}
				}
			}
			if(this.nowFloor!=this.nextFloor)                      //�ƶ�����
			{
				if(this.nowFloor<this.nextFloor)
					this.eleStyle = 1;
				else if(this.nowFloor>this.nextFloor)
					this.eleStyle = -1;
				else this.eleStyle = 0;
				
				if(this.eleStyle==1)
				{	
					this.Ey = (8-this.nowFloor-1)*50+3*(this.nowFloor-7+1);
					this.nowFloor = this.nowFloor+1;
				}
				else if(this.eleStyle==-1)
				{
					this.Ey = (8-this.nowFloor+1)*50+3*(this.nowFloor-7-1);
					this.nowFloor = this.nowFloor-1;
				}
				else if(this.eleStyle==0)
				{
					this.Ey = (8-this.nowFloor)*50+3*(this.nowFloor-7);
				}
			}
			else
				this.arrive(this.nextFloor);                //���õ��ﺯ��
			this.repaint();
		}
		public void arrive(int x) {                        //����ͣ��
			this.thecolor = new Color(20,20,255);
			this.repaint();
			try {
				Thread.sleep(1000);
			}catch (InterruptedException e) {
				e.printStackTrace();
			}
			if(this.rs)
				this.nowFloor = x;
			if(this.EleName=="right")                      //������л�����
			{
				if((elecs.rScene.sNode[0]==0)&(elecs.allScene.sNode[0]==0)) 
					this.nextFloor = this.nowFloor;
				else if(elecs.rScene.sNode[0]!=0)
				{
					this.nextFloor = elecs.rScene.sNode[0];
					elecs.rScene.pushnum();
				}
				else if(elecs.allScene.sNode[0]!=0)
				{
					this.nextFloor = elecs.allScene.sNode[0];
					elecs.allScene.pushnum();
				}
				else if(elecs.lScene.sNode[0]!=0)
				{
					this.nextFloor = elecs.lScene.sNode[0];
					elecs.lScene.pushnum();
				}
			}
			else if(this.EleName=="left")
			{
				if((elecs.lScene.sNode[0]==0)&(elecs.allScene.sNode[0]==0))
					this.nextFloor = this.nowFloor;
				else if(elecs.lScene.sNode[0]!=0)
				{
					this.nextFloor=elecs.lScene.sNode[0];
					elecs.lScene.pushnum();
				}
				else if(elecs.allScene.sNode[0]!=0)
				{
					this.nextFloor = elecs.allScene.sNode[0];
					elecs.allScene.pushnum();
				}
				else if(elecs.rScene.sNode[0]!=0)
				{
					this.nextFloor = elecs.rScene.sNode[0];
					elecs.rScene.pushnum();
				}
			}
			if(this.nowFloor<this.nextFloor)               //���õ���״̬
				this.eleStyle = 1;
			else if(this.nowFloor>this.nextFloor)
				this.eleStyle = -1;
			else this.eleStyle = 0;
		}
		public void reset() {                          //���ݸ�λ
			this.nowFloor = 1;
			this.nextFloor = 1;
			this.eleStyle = 0;
			this.Ey = (8-this.nowFloor)*50+3*(this.nowFloor-7);
			this.rs=false;
			repaint();
		}
		public void start() {                           //����
			this.thetel.start();
		}
		public void run() {
			while(true)
			{
				this.rs=true;
				this.move();
				try {
					Thread.sleep(800);
				}catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	public class innerButton extends Button{	          //�ڲ���ť
		public innerButton(String a)
		{
			super(a);
		}
	}
	public class inButton extends Button{          //������¥�㰴ť
		public inButton(String a)
		{
			super(a);
		}
	}
	public class floorButton extends Button{       //¥�㰴ť
		public floorButton(String a)
		{
			super(a);
		}
	}
	public class scene extends Panel{
		public int[] sNode = new int[10];            //����������
		String sceneName;                         //����������
		TextField thetext;                       //�������ı�1
		TextField thenum;						//�������ı�2
		public scene(String a) {                     //���캯��
			this.setLayout(new FlowLayout());
			thetext = new TextField(a);
			this.sceneName = a;
			thetext.setSize(10, 30);
			
			String s = new String();
			for(int i=0;i<10;i++) {
				s = s+" "+this.sNode[i];
			}
			thenum = new TextField(s);
			thetext.setEditable(false);
			thenum.setEditable(false);
			this.add(thetext);
			this.add(thenum);
		}
		public void addnum(int x,int eles,int elef) {          //���ҵ��ݻ�����������ֵ
			String s = new String();
			if(true)
			{
				if(eles==0)
				{
					this.sNode[0] = (x==0)?-1:x;
				}
				else if(eles==1)
				{
					for(int i=0;i<10;i++)
					{
						if(this.sNode[i]==x)
							break;
						else if(this.sNode[i]==0)
						{	
							this.sNode[i] = (x==0)?-1:x;
							break;
						}
						else if((this.sNode[i]>x)&(x>elef))
						{
							for(int j=9;j>i;j--)
							{
								this.sNode[j] = this.sNode[j-1];
							}
							this.sNode[i] = (x==0)?-1:x;
							break;							
						}
						else if((x<elef)&(this.sNode[i]<elef)&(this.sNode[i]<x))
						{
							for(int j=9;j>i;j--)
							{
								this.sNode[j] = this.sNode[j-1];
							}
							this.sNode[i] = (x==0)?-1:x;
							break;	
						}
					}
				}
				else if(eles==-1)
				{
					for(int i=0;i<10;i++)
					{
						if(this.sNode[i]==x)
							break;
						else if(this.sNode[i]==0)
						{	
							this.sNode[i] = (x==0)?-1:x;
							break;
						}
						else if((this.sNode[i]<x)&(x<elef))
						{
							for(int j=9;j>i;j--)
							{
								this.sNode[j] = this.sNode[j-1];
							}
							this.sNode[i] = (x==0)?-1:x;
							break;							
						}
						else if((x>elef)&(this.sNode[i]>elef)&(this.sNode[i]>x))
						{
							for(int j=9;j>i;j--)
							{
								this.sNode[j] = this.sNode[j-1];
							}
							this.sNode[i] = (x==0)?-1:x;
							break;	
						}
					}
				}
			}
			for(int i=0;i<10;i++) {
				s=s+" "+this.sNode[i];
			}
			this.thenum.setText(s);
		}
		public int newupnum(int x,int lf,int ls,int rf,int rs) {             //����������up��ť
			if((ls==0)&(rs==0))
			{
				if(Math.abs((x-lf))<=Math.abs((x-rf)))
					return 1;
				else return 2;
			}
			else if(ls==0)
				return 1;
			else if(rs==0)
				return 2;
			else if((ls==1)&(x>lf)&(rs==1)&(x>rf))
			{
				if(Math.abs((x-lf))<=Math.abs((x-rf)))
					return 1;
				else return 2;
			}
			else if((ls==1)&(x>lf))
				return 1;
			else if((rs==1)&(x>rf))
				return 2;
			else 
			{
				for(int i=0;i<10;i++)
				{
					if(this.sNode[i]==x)
						break;
					else if(this.sNode[i]==0)
					{
						this.sNode[i] = x;
						break;
					}
					else if(this.sNode[i]>x)
					{
						for(int j=9;j>i;j--)
						{
							this.sNode[j] = this.sNode[j-1];
						}
						this.sNode[i] = (x==0)?-1:x;
						break;	
					}
				}
				String s = new String();
				for(int i=0;i<10;i++) {
					s = s+" "+this.sNode[i];
				}
				this.thenum.setText(s);
				return 0;
			}
		}
		public int newdownnum(int x,int lf,int ls,int rf,int rs) {                 ////����������down��ť
			if((ls==0)&(rs==0))
			{
				if(Math.abs((x-lf))<=Math.abs((x-rf)))
					return 1;
				else return 2;
			}
			else if(ls==0)
				return 1;
			else if(rs==0)
				return 2;
			else if((ls==-1)&(x<lf)&(rs==-1)&(x<rf))
			{
				if(Math.abs((x-lf))<=Math.abs((x-rf)))
					return 1;
				else return 2;
			}
			else if((ls==-1)&(x<lf))
				return 1;
			else if((rs==-1)&(x<rf))
				return 2;
			else 
			{
				for(int i=0;i<10;i++)
				{
					if(this.sNode[i]==x)
						break;
					else if(this.sNode[i]==0)
					{
						this.sNode[i] = x;
						break;
					}
					else if(this.sNode[i]>x)
					{
						for(int j=9;j>i;j--)
						{
							this.sNode[j] = this.sNode[j-1];
						}
						this.sNode[i] = (x==0)?-1:x;
						break;	
					}
				}
				String s = new String();
				for(int i=0;i<10;i++) {
					s=s+" "+this.sNode[i];
				}
				this.thenum.setText(s);
				return 0;
			}
		}
		public void free() {                             //��λ����
			for(int i=0;i<10;i++)
				this.sNode[i] = 0;
			String s = new String();
			for(int i=0;i<10;i++) {
				s = s+" "+this.sNode[i];
			}
			this.thenum.setText(s);
		}
		public void pushnum() {                     //�Ƴ���һ��ֵ
			this.sNode[0]=0;
			for(int i=0;i<9;i++)
			{
				this.sNode[i]=this.sNode[i+1];
			}
			this.sNode[9]=0;
			String s = new String();
			for(int i=0;i<10;i++) {
				s = s+" "+this.sNode[i];
			}
			this.thenum.setText(s);
		}
	}
	
	public class floorRect extends Canvas{         //¥��ͼ�Σ����¥��
		int x;
		public floorRect(int x) {
			this.x = x;
		}
		public void paint(Graphics g) {
			if(this.x!=4)
				g.drawLine(0, 1, 55, 1);
			else g.drawLine(0, 1, 40, 1);
			if(this.x!=4)
				g.drawLine(0, 46, 55, 46);
			else g.drawLine(0, 46, 40, 46);
			if(this.x==4)
				g.drawLine(40, 0, 40, 50);
		}
	}
	public static void main(String args[]) {         //main����
			elevator ex = new elevator();
	}
}
